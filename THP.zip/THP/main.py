from data_preparation.fetch_lecture_notes import fetch_lecture_notes
from data_preparation.process_table import fetch_model_table
from vector_indexing.create_embeddings import create_embeddings
from vector_indexing.store_embeddings import store_embeddings
from query_handling.query_processing import query_embedding
from query_handling.generate_response import retrieve_relevant_docs, generate_response

# Fetch and prepare lecture notes
lectures = [
    "https://stanford-cs324.github.io/winter2022/lectures/introduction/",
    # Add more lecture URLs here
]
lecture_notes = [fetch_lecture_notes(url) for url in lectures]

# Fetch and prepare model architecture table
table_url = "https://github.com/Hannibal046/Awesome-LLM#milestone-papers"
model_table = fetch_model_table(table_url)

# Create and store embeddings
lecture_embeddings = create_embeddings(lecture_notes)
metadata = [{"lecture": "Introduction", "paragraph": idx} for idx, _ in enumerate(lecture_notes)]
store_embeddings(lecture_embeddings, metadata)

# Process a query
query = "What are some milestone model architectures and papers in the last few years?"
query_emb = query_embedding(query)
results = retrieve_relevant_docs(query_emb)
response = generate_response(results)
print(response)
