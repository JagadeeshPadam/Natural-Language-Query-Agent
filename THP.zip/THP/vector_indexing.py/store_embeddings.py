import chromadb
from chromadb.config import Settings

def store_embeddings(embeddings, metadata):
    client = chromadb.Client(Settings(chroma_dir="/path/to/store", persist_directory="/path/to/store"))
    collection = client.create_collection("lecture_notes")

    for idx, emb in enumerate(embeddings):
        collection.add_document({
            "id": str(idx),
            "embedding": emb,
            "metadata": metadata[idx]
        })

# Example usage:
metadata = [{"lecture": "Introduction", "paragraph": idx} for idx, _ in enumerate(lecture_notes)]
store_embeddings(lecture_embeddings, metadata)
