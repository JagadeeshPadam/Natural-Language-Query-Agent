from sentence_transformers import SentenceTransformer

def create_embeddings(texts):
    model = SentenceTransformer('all-MiniLM-L6-v2')
    embeddings = model.encode(texts, show_progress_bar=True)
    return embeddings

# Example usage:
lecture_embeddings = create_embeddings(lecture_notes)
