import openai
import chromadb
from chromadb.config import Settings

openai.api_key = 'your_openai_api_key'

def retrieve_relevant_docs(query_emb, top_k=5):
    client = chromadb.Client(Settings(chroma_dir="/path/to/store", persist_directory="/path/to/store"))
    collection = client.get_collection("lecture_notes")
    
    results = collection.query({
        "embedding": query_emb,
        "top_k": top_k,
        "include_metadata": True
    })
    return results

def generate_response(results):
    context = " ".join([doc['metadata']['text'] for doc in results['documents']])
    response = openai.Completion.create(
        model="text-davinci-003",
        prompt=f"Context: {context}\n\nQuestion: {query}\n\nAnswer:",
        max_tokens=150
    )
    return response.choices[0].text.strip()

# Example usage:
query_emb = query_embedding("What are some milestone model architectures and papers in the last few years?")
results = retrieve_relevant_docs(query_emb)
response = generate_response(results)
print(response)
