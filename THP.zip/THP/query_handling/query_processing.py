from sentence_transformers import SentenceTransformer

def query_embedding(query):
    model = SentenceTransformer('all-MiniLM-L6-v2')
    query_emb = model.encode([query], show_progress_bar=False)
    return query_emb[0]

# Example usage:
query = "What are some milestone model architectures and papers in the last few years?"
query_emb = query_embedding(query)
