import requests
from bs4 import BeautifulSoup

def fetch_lecture_notes(url):
    response = requests.get(url)
    soup = BeautifulSoup(response.text, 'html.parser')
    content = soup.get_text()
    return content

lectures = [
    "https://stanford-cs324.github.io/winter2022/lectures/introduction/",
    "https://stanford-cs324.github.io/winter2022/lectures/capabilities/",
    "https://stanford-cs324.github.io/winter2022/lectures/data/",
    "https://stanford-cs324.github.io/winter2022/lectures/legality/",
    "https://stanford-cs324.github.io/winter2022/lectures/training/"
]
lecture_notes = [fetch_lecture_notes(url) for url in lectures]