import pandas as pd

def fetch_model_table(url):
    tables = pd.read_html(url)
    model_table = tables[0]
    return model_table

# Example usage:
table_url = "https://github.com/Hannibal046/Awesome-LLM#milestone-papers"
model_table = fetch_model_table(table_url)
